
require File.join(File.dirname(__FILE__), %w[spec_helper])

describe LitleOnline do
end

# EOF
