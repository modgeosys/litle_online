module LitleOnline
  class Error < StandardError
  end
end
